import numpy as np
import math
from scipy.spatial import distance


def trip_distance(trip, distances):
    """Calculates simple (unpenalized) distance of a given trip.

    :param trip: an iteratable with destinations in order
    :param distances: the distance between destinations
    :return: total distance of the trip
    """

    total_dist = 0
    for i in range(len(trip) - 1):
        total_dist += distances[trip[i], trip[i + 1]]
    # print(i)
    total_dist += distances[trip[-1], trip[0]]

    return total_dist


def trip_distance_penalized(trip, distances, city_labels, all_primes, offset):
    """Calculates the `prime` (penalized) distance of a given trip.

    :param trip: an interable with destinations in order
    :param distances: the distances between destinations
    :param city_labels: the labels or city ids for destination in order
    :param all_primes: the list of all primes < max(city_labels)
    :param offset: the offet to calculating 10th trip. Used for within cluster TSP
    :return: total distance of trip
    """
    total_dist = 0
    penalize_next = 1.0
    for i in range(len(trip) - 1):
        total_dist += distances[trip[i], trip[i + 1]] * penalize_next
        if (((i + offset) % 10) == 0) and (city_labels[i] not in all_primes):
            penalize_next = 1.1
        else:
            penalize_next = 1.0
    total_dist += distances[trip[-1], trip[0]]

    return total_dist


def is_prime(n):
    """Test if number is a prime

    :param n: an integer
    :return: boolean of True if integer is prime
    """
    if n % 2 == 0 and n > 2:
        return False
    return all(n % i for i in range(3, int(math.sqrt(n)) + 1, 2))


def get_all_primes(n):
    """Get all primes from 0 to `n`

    :param n: an integer
    :return: a vector of primes
    """
    a = np.arange(1, n)
    is_prime_vec = np.vectorize(is_prime)
    pbools = is_prime_vec(a)
    primes = np.extract(pbools, a)

    return primes


def propose(solution, fix_start, fix_end):
    """Given a trip, propose a new solution using 2-opt

    :param solution: A trip
    :param fix_start: boolean if the starting location should be fixed
    :param fix_end: boolena if the ending location should be fixed
    :return: a proposed solution permuted using 2-opt
    """

    new_solution = solution.copy()
    if fix_start is not None:
        new_solution = new_solution[1:]
    if fix_end is not None:
        new_solution = new_solution[:-1]

    swap1, swap2 = np.random.choice(new_solution.shape[0], size=2, replace=False)
    if swap1 > swap2:
        new_solution = np.hstack(
            [
                np.flip(new_solution[:swap2]),
                new_solution[swap2:swap1],
                np.flip(new_solution[swap1:]),
            ]
        )
    else:
        new_solution = np.hstack(
            [
                new_solution[:swap1],
                np.flip(new_solution[swap1:swap2]),
                new_solution[swap2:],
            ]
        )

    if fix_start is not None:
        new_solution = np.insert(new_solution, 0, fix_start)
    if fix_end is not None:
        new_solution = np.insert(new_solution, new_solution.shape[0], fix_end)

    return new_solution


def run_epoch(
    Epoch,
    T,
    T_decay,
    L,
    X_old,
    E_old,
    distances,
    city_labels,
    all_primes,
    fix_start,
    fix_end,
    offset,
):
    """Run Simulated Annealing for multiple Epochs

    :param Epoch: Number of epoch to run
    :param T: The starting temperature
    :param T_decay: Rate of decay of temperature
    :param L: Number of batches within an epoch
    :param X_old: The initial trip
    :param E_old: The initial trip length
    :param distances: the distane matrix
    :param city_labels: The city ids
    :param all_primes: List of prime numbers
    :param fix_start: If starting location should be fixed
    :param fix_end: If ending location should be fixed
    :param offset: Offset to be added for calculating 10th leg
    :return: Best (shorted) trip, Lowest distance for best trip
    """

    L_int = L
    X_best = X_old
    E_best = E_old
    for e in range(Epoch):
        thresholds = np.random.uniform(0, 1, size=L_int)

        for l in range(L_int):
            X_new = propose(X_old, fix_start, fix_end)
            E_new = trip_distance_penalized(
                X_new, distances, city_labels, all_primes, offset=offset
            )

            alpha = min(1, np.exp((E_old - E_new) / T))
            # alpha = min(0, (E_old - E_new) / T)
            threshold = thresholds[l]

            if (E_new < E_old) or (alpha > threshold):

                # Let's keep track of the best one
                if E_new < E_old:
                    X_best = X_new
                    E_best = E_new

                E_old = E_new
                X_old = X_new

        if (e % 100) == 0:
            print("    >>>", E_new)

        # Let's calculate new L and T
        T = T * T_decay
        L = L * 1.01
        L_int = int(np.round(L, 0))

    return X_best, E_best


def run_simulated_annealing(
    data_arr,
    restarts=5,
    epochs=500,
    T=100,
    T_decay=0.8,
    L=10,
    city_labels=None,
    fix_start=None,
    fix_end=None,
    all_primes=None,
    offset=0,
    label="",
):
    """Run Simulated Annealing with warm restarts

    :param data_arr: matrix of location of all cities
    :param restarts: number of restarts
    :param epochs: Number of epochs per restart
    :param T: Initial temperature
    :param T_decay: Initial rate of decay of temperature
    :param L: Number of batches per epoch
    :param city_labels: Labels for cities
    :param fix_start: Boolean if start location should be fixed
    :param fix_end: Boolean if end location should be fixed
    :param all_primes: A list of primes
    :param offset: Inital offset when calculate 10th trip
    :param label: cluster label
    """

    n_points = data_arr.shape[0]
    if city_labels is None:
        city_labels = np.arange(n_points)

    init_sample = np.arange(n_points)
    if fix_start is not None:
        init_sample = np.delete(init_sample, fix_start)
    if fix_end is not None:
        init_sample = np.delete(init_sample, fix_end)

    X_old = np.random.choice(init_sample, size=init_sample.shape[0], replace=False)
    if fix_start is not None:
        X_old = np.insert(X_old, 0, fix_start)
    if fix_end is not None:
        X_old = np.insert(X_old, len(X_old), fix_end)

    distances = distance.squareform(distance.pdist(data_arr))
    all_primes = get_all_primes(n_points)

    E_old = trip_distance_penalized(X_old, distances, city_labels, all_primes, offset)

    for r in range(restarts):
        print("CLUSTER {}, RESTART {}: {}".format(label, r, E_old))
        X_old, E_old = run_epoch(
            epochs,
            T,
            T_decay,
            L,
            X_old,
            E_old,
            distances,
            city_labels,
            all_primes,
            fix_start,
            fix_end,
            offset,
        )
        T_decay = T_decay * 0.93

    return X_old, data_arr[X_old]
