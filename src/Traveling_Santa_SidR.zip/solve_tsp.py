import pandas as pd
import numpy as np
from scipy.spatial import distance

from simulated_annealing import *

from multiprocessing import Pool
from sklearn.cluster import MiniBatchKMeans
from functools import partial


def calculate_offsets(order_idx):
    """Calculate offsets for each cluster. Since the number of points per cluster is known,
       the number of legs within it is also known. We can precompute the offsets for each
       leg.

    :param order_idx: the order of cluster centers for the optimal trip
    :return: a list of offsets equal in length to number of clusters
    """
    offset = 0
    all_offset = []
    for segment in range(order_idx.shape[0]):
        all_offset.append(offset)
        n_in_cluster = (clusterer.labels_ == order_idx[segment]).sum()
        offset = (offset + n_in_cluster) % 10

    return all_offset


def get_cluster_paths(label, offsets):
    """For cluster with label `label`, calculate the optimal trip.

    :param label: Id of cluster
    :param offsets: Offsets for calculating 10th leg
    :returns: the optimal trip within the cluster
    """

    cluster_cities = clusterer.labels_ == order_idx[label]
    cluster = cities_arr[cluster_cities]
    fixed_start = smooth_points_id[2 * label]
    fixed_end = smooth_points_id[2 * label + 1]

    point_order_idx, point_order = run_simulated_annealing(
        cluster,
        restarts=5,
        fix_start=fixed_start,
        city_labels=np.argwhere(cluster_cities),
        fix_end=fixed_end,
        offset=offsets[label],
        label=label,
    )
    np.save("./cluster_{}.npy".format(label), point_order)
    return point_order


if __name__ == "__main__":
    cities = pd.read_csv("cities.csv", index_col=0)
    cities_arr = cities.values
    n_cities = cities_arr.shape[0]

    n_clusters = 300
    clusterer = MiniBatchKMeans(n_clusters=n_clusters, batch_size=1000)
    clusterer.fit(cities_arr)

    ids = clusterer.predict(cities_arr)
    cluster_centers = clusterer.cluster_centers_

    # Get the overall path
    order_idx, cluster_order = run_simulated_annealing(
        cluster_centers, restarts=5, fix_start=None, fix_end=None
    )

    starting_cluster = clusterer.labels_[0]
    roll_count = np.argwhere(order_idx == starting_cluster)[0][0]
    order_idx = np.roll(order_idx, roll_count)
    cluster_order = np.roll(cluster_order, roll_count, axis=0)

    np.save("./cluster_order.npy", order_idx)
    np.save("./cluster_labels.npy", clusterer.labels_)

    # Smooth
    smooth_route = []
    smooth_route_ids = []
    for i in range(n_clusters - 1):
        # What is the closest point between this and the next cluster?
        a = cities_arr[clusterer.labels_ == order_idx[i]]
        b = cities_arr[clusterer.labels_ == order_idx[i + 1]]

        A = distance.cdist(a, b)

        a_min, b_min = np.unravel_index(A.argmin(), A.shape)
        smooth_route += [a[a_min], b[b_min]]
        smooth_route_ids += [a_min, b_min]

    a = cities_arr[clusterer.labels_ == order_idx[-1]]
    b = cities_arr[clusterer.labels_ == order_idx[0]]
    cluster_dist = distance.cdist(a, b)
    a_min, b_min = np.unravel_index(cluster_dist.argmin(), cluster_dist.shape)
    smooth_route = [b[b_min]] + smooth_route + [a[a_min]]
    smooth_route_ids = [b_min] + smooth_route_ids + [a_min]

    smooth_points = np.vstack(smooth_route)
    smooth_points_id = np.vstack(smooth_route_ids).squeeze()

    offsets = calculate_offsets(order_idx)

    # Run for each cluster
    pool = Pool(4)
    _get_cluster_paths = partial(get_cluster_paths, offsets=offsets)
    all_paths = pool.map(get_cluster_paths, range(n_clusters))

    paths_stacked = np.vstack(all_paths)

    np.save("./all_paths.npy", paths_stacked)
