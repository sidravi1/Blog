import os
import pandas as pd

def write_tsp(nodes, filename, name='traveling-santa-2018-prime-paths'):
    # From https://www.kaggle.com/blacksix/concorde-for-5-hours.
    with open(filename, 'w') as f:
        f.write('NAME : %s\n' % name)
        f.write('COMMENT : %s\n' % name)
        f.write('TYPE : TSP\n')
        f.write('DIMENSION : %d\n' % len(cities))
        f.write('EDGE_WEIGHT_TYPE : EUC_2D\n')
        f.write('NODE_COORD_SECTION\n')
        for row in cities.itertuples():
            f.write('%d %.11f %.11f\n' % (row.Index + 1, row.X, row.Y))
        f.write('EOF\n')

def write_parameters(parameters, filename='./LKH-2.0.9/params.par'):
    with open(filename, 'w') as f:
        for param, value in parameters:
            f.write("{} = {}\n".format(param, value))
    print("Parameters saved as", filename)

if __name__ == "__main__":
    
    cities = pd.read_csv('./cities.csv', index_col=['CityId'], nrows=None)
    cities = cities * 1000  # not sure if coords are rounded as concorde
        

    write_tsp(cities, './LKH-2.0.9/cities.tsp')

    parameters = [
        ("PROBLEM_FILE", "cities.tsp"),
        ("OUTPUT_TOUR_FILE", "tsp_solution.csv"),
        ("SEED", 2018),
        ('CANDIDATE_SET_TYPE', 'POPMUSIC'), #'NEAREST-NEIGHBOR', 'ALPHA'),
        ('INITIAL_PERIOD', 10000),
        ('MAX_TRIALS', 1000),
    ]
    write_parameters(parameters)
